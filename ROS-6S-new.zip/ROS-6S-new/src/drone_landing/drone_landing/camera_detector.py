#!/usr/bin/env python3
"""
Camera Detector Node
--------------------
Processes the downward-facing camera image to detect the landing platform
using OpenCV HSV colour thresholding on the yellow circle painted on the pad.

The detected pixel centroid is back-projected to a world-space XY offset using
the drone's current altitude and the camera intrinsics.

Subscribes:  /drone/camera/image_raw   (sensor_msgs/Image)
             /drone/pose               (geometry_msgs/PoseStamped)
Publishes:   /platform/pose/camera     (geometry_msgs/PoseStamped)
             /camera/platform_detected (std_msgs/Bool)
             /camera/detection_status  (std_msgs/String)
             /drone/camera/debug_image (sensor_msgs/Image)   — annotated frame
"""

import math

import cv2
import numpy as np
import rclpy
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Bool, String


def ros_img_to_bgr(msg: Image) -> np.ndarray:
    """Convert a sensor_msgs/Image (rgb8 or bgr8) to a BGR numpy array."""
    arr = np.frombuffer(bytes(msg.data), dtype=np.uint8).reshape(
        msg.height, msg.width, 3)
    if msg.encoding == 'rgb8':
        arr = arr[:, :, ::-1]   # RGB → BGR
    return arr.copy()           # writable copy


def bgr_to_ros_img(arr: np.ndarray, stamp, frame_id: str) -> Image:
    """Convert a BGR numpy array to a sensor_msgs/Image (bgr8)."""
    msg           = Image()
    msg.header.stamp    = stamp
    msg.header.frame_id = frame_id
    msg.height    = arr.shape[0]
    msg.width     = arr.shape[1]
    msg.encoding  = 'bgr8'
    msg.step      = arr.shape[1] * 3
    msg.data      = arr.tobytes()
    return msg


class CameraDetector(Node):
    """Detects the landing-pad yellow circle in downward camera images."""

    # ── HSV range for the yellow pad circle ──────────────────────────────
    # Gazebo lighting desaturates rendered colours significantly, so we
    # use a generous hue window and a low saturation/value floor.
    YELLOW_LOW  = np.array([15,  40,  40])
    YELLOW_HIGH = np.array([45, 255, 255])

    # ── Camera intrinsics (640×480, 60° horizontal FOV) ──────────────────
    IMG_W = 640
    IMG_H = 480
    FOV_H = math.radians(60.0)
    FX    = (IMG_W / 2.0) / math.tan(FOV_H / 2.0)   # ≈ 554.3 px
    FY    = FX
    CX    = IMG_W / 2.0   # 320 px
    CY    = IMG_H / 2.0   # 240 px

    # ── Minimum blob area to accept as valid detection ────────────────────
    MIN_AREA = 80   # px²  — low enough to catch the pad at cruise altitude

    def __init__(self):
        super().__init__('camera_detector')

        self.declare_parameter('platform_z', 0.025)   # metres — known pad height

        self.drone_pose      = None
        self.platform_z      = self.get_parameter('platform_z').value
        self._prev_detected  = False

        # ── Subscribers ──────────────────────────────────────────────────
        self.create_subscription(
            Image, '/drone/camera/image_raw',
            self._image_cb, 10)
        self.create_subscription(
            PoseStamped, '/drone/pose',
            self._drone_pose_cb, 10)

        # ── Publishers ───────────────────────────────────────────────────
        self.cam_plat_pub  = self.create_publisher(
            PoseStamped, '/platform/pose/camera', 10)
        self.detected_pub  = self.create_publisher(
            Bool, '/camera/platform_detected', 10)
        self.status_pub    = self.create_publisher(
            String, '/camera/detection_status', 10)
        self.debug_img_pub = self.create_publisher(
            Image, '/drone/camera/debug_image', 10)

        self.get_logger().info(
            'Camera detector started — '
            'listening on /drone/camera/image_raw')

    # ─────────────────────────────────────────────────────────────────────
    def _drone_pose_cb(self, msg: PoseStamped):
        self.drone_pose = msg.pose

    # ─────────────────────────────────────────────────────────────────────
    def _image_cb(self, msg: Image):
        if self.drone_pose is None:
            return

        try:
            cv_img = ros_img_to_bgr(msg)
        except Exception as e:
            self.get_logger().warn(f'Image conversion error: {e}')
            return

        # ── HSV thresholding ─────────────────────────────────────────────
        hsv  = cv2.cvtColor(cv_img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.YELLOW_LOW, self.YELLOW_HIGH)

        k    = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  k)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k)

        # ── Contour detection ────────────────────────────────────────────
        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detected = False
        debug    = cv_img.copy()

        if contours:
            largest = max(contours, key=cv2.contourArea)
            area    = cv2.contourArea(largest)

            if area >= self.MIN_AREA:
                M = cv2.moments(largest)
                if M['m00'] > 0:
                    cx_px = M['m10'] / M['m00']
                    cy_px = M['m01'] / M['m00']

                    # ── Back-project pixel → world XY ─────────────────
                    # Camera mounted on drone looking straight down (pitch=+π/2).
                    # With the drone facing +X and this mount:
                    #   image right  (+dx_px) → world +Y
                    #   image down   (+dy_px) → world −X
                    height = max(
                        self.drone_pose.position.z - self.platform_z, 0.1)

                    dx_px = cx_px - self.CX
                    dy_px = cy_px - self.CY

                    x_offset = -(dy_px / self.FY) * height
                    y_offset =  (dx_px / self.FX) * height

                    plat_x = self.drone_pose.position.x + x_offset
                    plat_y = self.drone_pose.position.y + y_offset

                    # ── Publish camera-based platform estimate ─────────
                    p = PoseStamped()
                    p.header.stamp    = msg.header.stamp
                    p.header.frame_id = 'map'
                    p.pose.position.x = plat_x
                    p.pose.position.y = plat_y
                    p.pose.position.z = self.platform_z
                    p.pose.orientation.w = 1.0
                    self.cam_plat_pub.publish(p)

                    detected = True

                    if not self._prev_detected:
                        self.get_logger().info(
                            f'[CAMERA] Platform ACQUIRED  '
                            f'area={area:.0f}px²  '
                            f'offset=({x_offset:+.2f},{y_offset:+.2f})m  '
                            f'h={height:.1f}m')

                    # ── Annotate debug image ───────────────────────────
                    cv2.drawContours(debug, [largest], -1, (0, 255, 0), 2)
                    cv2.circle(debug, (int(cx_px), int(cy_px)), 10,
                               (0, 0, 255), -1)
                    cv2.line(debug, (int(self.CX), 0),
                             (int(self.CX), self.IMG_H), (100, 100, 100), 1)
                    cv2.line(debug, (0, int(self.CY)),
                             (self.IMG_W, int(self.CY)), (100, 100, 100), 1)
                    cv2.putText(
                        debug,
                        f'offset ({x_offset:+.2f},{y_offset:+.2f})m  '
                        f'h={height:.1f}m',
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                        0.65, (0, 255, 0), 2)
                    cv2.putText(
                        debug,
                        f'PLATFORM DETECTED  area={area:.0f}px',
                        (10, 58), cv2.FONT_HERSHEY_SIMPLEX,
                        0.65, (0, 220, 0), 2)

        if not detected and self._prev_detected:
            self.get_logger().info(
                '[CAMERA] Platform LOST — controller falls back to ground truth')

        self._prev_detected = detected

        # ── Publish Bool flag ────────────────────────────────────────────
        det_msg      = Bool()
        det_msg.data = detected
        self.detected_pub.publish(det_msg)

        # ── Publish status string ────────────────────────────────────────
        status      = String()
        status.data = 'DETECTED' if detected else 'NOT DETECTED'
        self.status_pub.publish(status)

        # ── Annotate + publish debug image ───────────────────────────────
        label_color = (0, 255, 0) if detected else (0, 60, 220)
        cv2.putText(
            debug, status.data,
            (10, self.IMG_H - 15),
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, label_color, 2)
        try:
            self.debug_img_pub.publish(
                bgr_to_ros_img(debug, msg.header.stamp, 'drone/camera_optical'))
        except Exception:
            pass


def main(args=None):
    rclpy.init(args=args)
    node = CameraDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
