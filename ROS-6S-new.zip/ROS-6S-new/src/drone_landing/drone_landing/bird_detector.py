#!/usr/bin/env python3
"""
Bird Detector Node
------------------
Simulates an onboard proximity / collision-avoidance sensor that detects birds
within a configurable sensor_range (metres).

Implementation: reads Gazebo ground-truth model states and computes the
3-D distance from the drone to each bird.  An obstacle is "detected" only
when it falls inside the sensor bubble — exactly what a real radar, lidar or
stereo-camera would report.  Nothing outside sensor range is published, so
the landing controller only reacts to what the sensor can physically "see".

Subscribes:  /gazebo/model_states   (gazebo_msgs/ModelStates)
             /drone/pose            (geometry_msgs/PoseStamped)
Publishes:   /detected_obstacles    (geometry_msgs/PoseArray)
             /obstacle/status       (std_msgs/String)
"""

import math

import rclpy
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import PoseArray, PoseStamped
from rclpy.node import Node
from std_msgs.msg import String

BIRD_NAMES = {'bird_1', 'bird_2', 'bird_3'}


class BirdDetector(Node):

    def __init__(self):
        super().__init__('bird_detector')

        self.declare_parameter('sensor_range', 3.0)    # metres
        self.declare_parameter('update_rate',  20.0)   # Hz

        self.sensor_range = self.get_parameter('sensor_range').value
        rate              = self.get_parameter('update_rate').value

        self.drone_pose = None
        self.bird_poses = {}   # name → geometry_msgs/Pose

        # ── Subscribers ──────────────────────────────────────────────────
        self.create_subscription(
            ModelStates, '/gazebo/model_states',
            self._model_states_cb, 10)
        self.create_subscription(
            PoseStamped, '/drone/pose',
            self._drone_pose_cb, 10)

        # ── Publishers ───────────────────────────────────────────────────
        self.obstacle_pub = self.create_publisher(
            PoseArray, '/detected_obstacles', 10)
        self.status_pub   = self.create_publisher(
            String, '/obstacle/status', 10)

        self.timer = self.create_timer(1.0 / rate, self._publish_detections)
        self.get_logger().info(
            f'Bird detector started — sensor range {self.sensor_range:.1f} m')

    # ─────────────────────────────────────────────────────────────────────
    def _drone_pose_cb(self, msg: PoseStamped):
        self.drone_pose = msg.pose

    def _model_states_cb(self, msg: ModelStates):
        for i, name in enumerate(msg.name):
            if name in BIRD_NAMES:
                self.bird_poses[name] = msg.pose[i]

    # ─────────────────────────────────────────────────────────────────────
    def _publish_detections(self):
        if self.drone_pose is None:
            return

        dx = self.drone_pose.position.x
        dy = self.drone_pose.position.y
        dz = self.drone_pose.position.z

        in_range_poses  = []
        in_range_labels = []

        for name, pose in self.bird_poses.items():
            dist = math.sqrt(
                (pose.position.x - dx) ** 2 +
                (pose.position.y - dy) ** 2 +
                (pose.position.z - dz) ** 2)

            if dist <= self.sensor_range:
                in_range_poses.append(pose)
                in_range_labels.append(f'{name}@{dist:.1f}m')

        arr             = PoseArray()
        arr.header.stamp    = self.get_clock().now().to_msg()
        arr.header.frame_id = 'map'
        arr.poses           = in_range_poses
        self.obstacle_pub.publish(arr)

        status      = String()
        status.data = ('OBSTACLES: ' + ', '.join(in_range_labels)
                       if in_range_labels else 'clear')
        self.status_pub.publish(status)


def main(args=None):
    rclpy.init(args=args)
    node = BirdDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
