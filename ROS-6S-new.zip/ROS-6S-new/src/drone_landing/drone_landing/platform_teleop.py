#!/usr/bin/env python3
"""
Platform Teleop Node
--------------------
Control the landing platform manually with WASD keys.

  W / S  →  move platform +X / −X  (forward / back)
  A / D  →  move platform +Y / −Y  (left / right)
  Space  →  stop
  Q / Ctrl-C  →  quit

The node reads raw key events in a background thread and sets a velocity
direction.  A 20 Hz timer integrates position and calls SetEntityState so
the platform slides smoothly.

Run in a separate terminal alongside the simulation:
  ros2 run drone_landing platform_teleop

Launch simulation without the auto-mover so this node has sole control:
  ros2 launch drone_landing simulation_launch.py manual_platform:=true
"""

import sys
import termios
import threading
import tty

import rclpy
from gazebo_msgs.msg import EntityState
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import Point, Quaternion
from rclpy.node import Node
from std_msgs.msg import String

BANNER = """
╔══════════════════════════════════════╗
║   Platform Teleop — WASD + L/K      ║
╠══════════════════════════════════════╣
║  W / S  →  platform forward / back  ║
║  A / D  →  platform left  / right   ║
║  Space  →  stop platform            ║
║  L      →  START descent / land     ║
║  K      →  ABORT  — fly back up     ║
║  Q      →  quit                     ║
╚══════════════════════════════════════╝
"""

# key → (vx_dir, vy_dir)  — platform movement only
KEY_MAP = {
    'w': ( 1,  0),
    's': (-1,  0),
    'a': ( 0,  1),
    'd': ( 0, -1),
    ' ': ( 0,  0),
}


class PlatformTeleop(Node):

    def __init__(self):
        super().__init__('platform_teleop')

        self.declare_parameter('speed',           0.8)    # m/s
        self.declare_parameter('platform_height', 0.025)  # m
        self.declare_parameter('x_limit',         4.0)    # ±metres
        self.declare_parameter('y_limit',         4.0)
        self.declare_parameter('update_rate',     20.0)   # Hz

        self.speed   = self.get_parameter('speed').value
        self.height  = self.get_parameter('platform_height').value
        self.x_limit = self.get_parameter('x_limit').value
        self.y_limit = self.get_parameter('y_limit').value
        rate         = self.get_parameter('update_rate').value
        self.dt      = 1.0 / rate

        # Platform state
        self.plat_x = 0.0
        self.plat_y = 0.0
        self.vx_dir = 0    # −1 / 0 / +1
        self.vy_dir = 0

        self._running = True

        # Gazebo service
        self.client = self.create_client(SetEntityState, '/gazebo/set_entity_state')
        self.get_logger().info('Waiting for /gazebo/set_entity_state …')
        self.client.wait_for_service(timeout_sec=30.0)
        self.get_logger().info('Service ready.')

        # Publisher for landing commands sent to the landing controller
        self.cmd_pub = self.create_publisher(String, '/landing/command', 10)

        # Position update timer
        self.timer = self.create_timer(self.dt, self._update)

        # Keyboard thread
        self._kb_thread = threading.Thread(
            target=self._read_keys, daemon=True)
        self._kb_thread.start()

        print(BANNER)
        self.get_logger().info(
            f'Platform teleop active  speed={self.speed} m/s  '
            f'limits=±{self.x_limit}m')

    # ─────────────────────────────────────────────────────────────────────
    def _read_keys(self):
        fd          = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            while self._running:
                ch = sys.stdin.read(1).lower()

                if ch in KEY_MAP:
                    self.vx_dir, self.vy_dir = KEY_MAP[ch]
                    if ch == ' ':
                        self.get_logger().info('Platform STOPPED')
                    else:
                        self.get_logger().info(
                            f'Moving  key={ch.upper()}  '
                            f'dir=({self.vx_dir:+d},{self.vy_dir:+d})')

                elif ch == 'l':
                    msg = String(); msg.data = 'DESCEND'
                    self.cmd_pub.publish(msg)
                    self.get_logger().info(
                        '[L] DESCEND command sent — drone will land on platform')

                elif ch == 'k':
                    msg = String(); msg.data = 'ASCEND'
                    self.cmd_pub.publish(msg)
                    self.get_logger().info(
                        '[K] ASCEND command sent — drone returning to cruise altitude')

                elif ch in ('q', '\x03'):   # Q or Ctrl-C
                    self.get_logger().info('Teleop quit.')
                    self._running = False
                    rclpy.shutdown()
                    break
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    # ─────────────────────────────────────────────────────────────────────
    def _update(self):
        if not self._running:
            return

        # Integrate velocity
        self.plat_x += self.vx_dir * self.speed * self.dt
        self.plat_y += self.vy_dir * self.speed * self.dt

        # Clamp to arena limits
        self.plat_x = max(-self.x_limit, min(self.x_limit, self.plat_x))
        self.plat_y = max(-self.y_limit, min(self.y_limit, self.plat_y))

        # Teleport platform
        state           = EntityState()
        state.name      = 'landing_platform'
        state.pose.position = Point(
            x=self.plat_x, y=self.plat_y, z=self.height)
        state.pose.orientation = Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)
        state.reference_frame  = 'world'

        req       = SetEntityState.Request()
        req.state = state
        self.client.call_async(req)


def main(args=None):
    rclpy.init(args=args)
    node = PlatformTeleop()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        # Restore terminal if rclpy.shutdown() wasn't already called
        try:
            rclpy.shutdown()
        except Exception:
            pass


if __name__ == '__main__':
    main()
