#!/usr/bin/env python3
"""
Bird Mover Node
---------------
Moves simulated bird obstacles along independent circular paths at the drone's
cruise altitude (~3 m).  Each bird has its own radius, speed and starting
phase so they spread across the workspace and naturally cross the drone's path.

Uses /gazebo/set_entity_state to teleport each bird every control tick.
"""

import math

import rclpy
from gazebo_msgs.msg import EntityState
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import Point, Quaternion
from rclpy.node import Node

# (name, radius_x, radius_y, altitude, speed_rad_s, phase_rad)
#
# All three birds orbit tightly around (0, 0) — the centre of the drone's
# workspace.  The platform swings ±2 m in X and ±1.5 m in Y, so the drone
# always passes through this region.  Radius ≤ 1.3 m guarantees the birds
# cross the drone's path during every lap and the 3 m sensor bubble fires.
BIRDS = [
    ('bird_1', 1.2, 1.2, 3.0, 0.7, 0.000),    # fast tight circle
    ('bird_2', 1.3, 0.9, 3.1, 0.5, 2.094),    # medium ellipse, offset phase
    ('bird_3', 0.9, 1.3, 2.9, 0.8, 4.189),    # fastest, different tilt
]


class BirdMover(Node):

    def __init__(self):
        super().__init__('bird_mover')

        self.declare_parameter('update_rate', 20.0)
        rate = self.get_parameter('update_rate').value

        self.client = self.create_client(
            SetEntityState, '/gazebo/set_entity_state')
        self.get_logger().info('BirdMover — waiting for /gazebo/set_entity_state …')
        self.client.wait_for_service(timeout_sec=30.0)
        self.get_logger().info('Service ready.')

        self.start_time = self.get_clock().now()
        self.timer = self.create_timer(1.0 / rate, self._tick)
        self.get_logger().info(
            f'Bird mover started — {len(BIRDS)} birds in flight')

    # ─────────────────────────────────────────────────────────────────────
    def _tick(self):
        t = (self.get_clock().now() - self.start_time).nanoseconds * 1e-9
        for name, rx, ry, alt, speed, phase in BIRDS:
            angle = speed * t + phase
            x = rx * math.cos(angle)
            y = ry * math.sin(angle)

            state           = EntityState()
            state.name      = name
            state.pose.position = Point(x=x, y=y, z=alt)
            state.pose.orientation = Quaternion(
                x=0.0, y=0.0, z=0.0, w=1.0)
            state.reference_frame = 'world'

            req       = SetEntityState.Request()
            req.state = state
            self.client.call_async(req)


def main(args=None):
    rclpy.init(args=args)
    node = BirdMover()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
