#!/usr/bin/env python3
"""
Landing Controller Node
-----------------------
PID-based state machine that lands the drone on a moving platform.

States:
  WAITING    → hold at spawn position for 3 s
  TRACKING   → follow platform XY at cruise altitude using GROUND TRUTH (GPS)
  DESCENDING → camera lock required — drone HOLDS if no visual; descends only
               when camera confirms the platform is visible
  LANDING    → final slow approach, camera only
  LANDED     → lock drone on platform

Camera policy (Option A):
  TRACKING uses ground truth from the state_estimator (simulates GPS / INS).
  The instant the drone enters DESCENDING the ground-truth subscription for
  platform XY is ignored.  Only /platform/pose/camera drives XY.  If the
  camera loses the blob the drone freezes at its current position until visual
  lock is re-acquired.  This makes the camera a hard requirement for landing —
  it cannot land without it.

Bird-avoidance policy (Option D):
  /detected_obstacles (PoseArray from bird_detector) drives a repulsion
  velocity that is added on top of normal PID output in TRACKING and
  DESCENDING states.  The avoidance gain is high enough that the sidestep is
  clearly visible (~1-2 m).  State-change events (bird enters / leaves sensor
  range) are logged once rather than every tick.  A red arrow Marker is
  published on /avoidance_vector so RViz shows the push direction.

Subscribes:  /drone/pose
             /platform/pose          (ground truth — TRACKING only)
             /platform/pose/camera   (camera — DESCENDING + LANDING)
             /camera/platform_detected
             /detected_obstacles
Publishes:   /landing/status
             /avoidance_vector       (visualization_msgs/Marker)
Uses:        /gazebo/set_entity_state
"""

import math

import rclpy
from gazebo_msgs.msg import EntityState
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import Point, PoseArray, PoseStamped, Quaternion
from rclpy.node import Node
from std_msgs.msg import Bool, String
from visualization_msgs.msg import Marker


# ======================================================================
class PIDController:
    """1-D PID with output clamping and integral anti-windup."""

    def __init__(self, kp, ki, kd, out_max):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.out_max   = out_max
        self._integral = 0.0
        self._prev_err = 0.0

    def reset(self):
        self._integral = 0.0
        self._prev_err = 0.0

    def compute(self, error, dt):
        if dt <= 0.0:
            return 0.0
        self._integral += error * dt
        if self.ki > 1e-9:
            i_max = self.out_max / self.ki
            self._integral = max(-i_max, min(i_max, self._integral))
        derivative    = (error - self._prev_err) / dt
        self._prev_err = error
        out = (self.kp * error
               + self.ki * self._integral
               + self.kd * derivative)
        return max(-self.out_max, min(self.out_max, out))


# ======================================================================
class LandingController(Node):

    WAITING    = 'WAITING'
    TRACKING   = 'TRACKING'
    DESCENDING = 'DESCENDING'
    LANDING    = 'LANDING'
    LANDED     = 'LANDED'

    def __init__(self):
        super().__init__('landing_controller')

        # ── Parameters ───────────────────────────────────────────────────
        self.declare_parameter('pid_xy_kp',           3.0)
        self.declare_parameter('pid_xy_ki',           0.05)
        self.declare_parameter('pid_xy_kd',           0.8)
        self.declare_parameter('pid_z_kp',            1.2)
        self.declare_parameter('pid_z_ki',            0.0)
        self.declare_parameter('pid_z_kd',            0.5)
        self.declare_parameter('max_horizontal_vel',  3.0)
        self.declare_parameter('max_vertical_vel',    1.0)
        self.declare_parameter('cruise_altitude',     3.0)
        self.declare_parameter('alignment_threshold', 0.5)
        self.declare_parameter('align_hold_time',     1.5)
        self.declare_parameter('descent_speed',       0.3)
        self.declare_parameter('final_descent_speed', 0.10)
        self.declare_parameter('landing_height',      0.08)
        self.declare_parameter('update_rate',         50.0)
        self.declare_parameter('spawn_x',             0.0)
        self.declare_parameter('spawn_y',             0.0)
        self.declare_parameter('spawn_z',             5.0)
        self.declare_parameter('avoid_gain',          5.0)
        self.declare_parameter('avoid_max_vel',       2.0)

        kp_xy = self.get_parameter('pid_xy_kp').value
        ki_xy = self.get_parameter('pid_xy_ki').value
        kd_xy = self.get_parameter('pid_xy_kd').value
        kp_z  = self.get_parameter('pid_z_kp').value
        ki_z  = self.get_parameter('pid_z_ki').value
        kd_z  = self.get_parameter('pid_z_kd').value
        max_h = self.get_parameter('max_horizontal_vel').value
        max_v = self.get_parameter('max_vertical_vel').value

        self.cruise_alt    = self.get_parameter('cruise_altitude').value
        self.align_thresh  = self.get_parameter('alignment_threshold').value
        self.align_hold    = self.get_parameter('align_hold_time').value
        self.descent_speed = self.get_parameter('descent_speed').value
        self.final_speed   = self.get_parameter('final_descent_speed').value
        self.land_height   = self.get_parameter('landing_height').value
        rate               = self.get_parameter('update_rate').value
        self.spawn_x       = self.get_parameter('spawn_x').value
        self.spawn_y       = self.get_parameter('spawn_y').value
        self.spawn_z       = self.get_parameter('spawn_z').value
        self.avoid_gain    = self.get_parameter('avoid_gain').value
        self.avoid_max_vel = self.get_parameter('avoid_max_vel').value

        self.dt = 1.0 / rate

        # ── PID controllers ───────────────────────────────────────────────
        self.pid_x = PIDController(kp_xy, ki_xy, kd_xy, max_h)
        self.pid_y = PIDController(kp_xy, ki_xy, kd_xy, max_h)
        self.pid_z = PIDController(kp_z,  ki_z,  kd_z,  max_v)

        # ── Mission state ─────────────────────────────────────────────────
        self.state            = self.WAITING
        self.drone_pose       = None
        self.platform_pose    = None   # ground truth (TRACKING only)
        self.start_time       = None
        self.aligned_duration = 0.0
        self.target_altitude  = self.spawn_z
        self._tick            = 0

        # Camera state
        self._camera_platform   = None    # geometry_msgs/Pose from camera
        self._camera_detected   = False
        self._camera_hold_warn  = False   # rate-limit "holding" log
        self._cam_lock_logged   = False   # log "LOCK ACQUIRED" once per descent

        # Manual command state
        self._manual_descent    = False   # True after user presses L

        # Obstacle / avoidance state
        self._obstacles       = []    # list[geometry_msgs/Pose] in sensor range
        self._prev_obs_count  = 0     # to detect enter/exit events

        # ── ROS interfaces ────────────────────────────────────────────────
        self.create_subscription(
            PoseStamped, '/drone/pose',            self._drone_cb, 10)
        self.create_subscription(
            PoseStamped, '/platform/pose',         self._platform_cb, 10)
        self.create_subscription(
            PoseStamped, '/platform/pose/camera',  self._cam_platform_cb, 10)
        self.create_subscription(
            Bool,        '/camera/platform_detected', self._cam_detected_cb, 10)
        self.create_subscription(
            PoseArray,   '/detected_obstacles',    self._obstacles_cb, 10)
        self.create_subscription(
            String,      '/landing/command',       self._command_cb,   10)

        self.set_client = self.create_client(
            SetEntityState, '/gazebo/set_entity_state')
        self.get_logger().info('Waiting for /gazebo/set_entity_state …')
        self.set_client.wait_for_service(timeout_sec=30.0)
        self.get_logger().info('Service ready.')

        self.status_pub   = self.create_publisher(String,  '/landing/status',    10)
        self.avoid_marker = self.create_publisher(Marker,  '/avoidance_vector',  10)

        self.timer = self.create_timer(self.dt, self._control_loop)
        self.get_logger().info('Landing controller ready.')

    # ─────────────────────────────────────────────────────────────────────
    def _drone_cb(self, msg):
        self.drone_pose = msg.pose

    def _platform_cb(self, msg):
        self.platform_pose = msg.pose

    def _cam_platform_cb(self, msg: PoseStamped):
        self._camera_platform = msg.pose

    def _cam_detected_cb(self, msg: Bool):
        self._camera_detected = msg.data

    def _obstacles_cb(self, msg: PoseArray):
        self._obstacles = list(msg.poses)

    def _command_cb(self, msg: String):
        cmd = msg.data.upper().strip()
        if cmd == 'DESCEND':
            self._manual_descent = True
            if self.state in (self.TRACKING, self.WAITING, self.LANDED):
                if self.drone_pose:
                    self.target_altitude = self.drone_pose.position.z
                self.pid_z.reset()
                self._cam_lock_logged = False
                self._camera_hold_warn = False
                self.state = self.DESCENDING
            self.get_logger().info(
                '[CMD] ↓ MANUAL DESCENT — continuously chasing platform down')

        elif cmd == 'ASCEND':
            self._manual_descent = False
            prev = self.state
            self.state = self.TRACKING
            self.aligned_duration = 0.0
            self.pid_x.reset()
            self.pid_y.reset()
            self.pid_z.reset()
            self.get_logger().info(
                f'[CMD] ↑ ASCEND — returning to cruise altitude '
                f'(was {prev})')

    # ─────────────────────────────────────────────────────────────────────
    def _control_loop(self):
        if self.drone_pose is None or self.platform_pose is None:
            return

        if self.start_time is None:
            self.start_time = self.get_clock().now()

        elapsed = (self.get_clock().now() - self.start_time).nanoseconds * 1e-9

        dp = self.drone_pose.position
        pp = self.platform_pose.position   # ground truth — used for metrics only

        horiz_err    = math.sqrt((pp.x - dp.x) ** 2 + (pp.y - dp.y) ** 2)
        height_above = dp.z - pp.z

        if self.state == self.WAITING:
            self._do_waiting(elapsed, dp)
        elif self.state == self.TRACKING:
            self._do_tracking(dp, pp, horiz_err)
        elif self.state == self.DESCENDING:
            self._do_descending(dp, pp, height_above)
        elif self.state == self.LANDING:
            self._do_landing(dp, pp, height_above)
        elif self.state == self.LANDED:
            self._do_landed(dp, pp)

        # ── Status ────────────────────────────────────────────────────────
        cam_tag = '[CAM]' if self._camera_detected else '[GPS]'
        man_tag = '[MANUAL]' if self._manual_descent else ''
        avd_tag = ' AVOIDING' if self._obstacles else ''
        s      = String()
        s.data = (f'{self.state}{cam_tag}{man_tag}{avd_tag} | '
                  f'xy={horiz_err:.2f}m | alt={height_above:.2f}m')
        self.status_pub.publish(s)

        self._tick += 1
        if self._tick % 50 == 0:
            self.get_logger().info(s.data)

    # ── State handlers ────────────────────────────────────────────────────

    def _do_waiting(self, elapsed, dp):
        self._move_toward(dp, self.spawn_x, self.spawn_y, self.spawn_z)
        if elapsed > 3.0:
            self.pid_x.reset(); self.pid_y.reset(); self.pid_z.reset()
            self.state = self.TRACKING
            self.get_logger().info(
                '>> TRACKING  [GPS / ground-truth]  following platform XY')

    def _do_tracking(self, dp, pp, horiz_err):
        """Follow platform using ground truth. Apply bird avoidance."""
        ax, ay = self._avoidance_with_events(dp)

        vx = self.pid_x.compute(pp.x - dp.x, self.dt) + ax
        vy = self.pid_y.compute(pp.y - dp.y, self.dt) + ay
        vz = self.pid_z.compute(self.cruise_alt - dp.z, self.dt)

        self._set_entity(dp.x + vx * self.dt,
                         dp.y + vy * self.dt,
                         dp.z + vz * self.dt)
        self._publish_avoidance_marker(dp, ax, ay)

        if horiz_err < self.align_thresh:
            self.aligned_duration += self.dt
        else:
            self.aligned_duration = 0.0

        if self.aligned_duration >= self.align_hold:
            self.target_altitude  = dp.z
            self._cam_lock_logged = False   # reset so we log on first lock
            self.pid_z.reset()
            self.state = self.DESCENDING
            self.get_logger().info(
                f'>> DESCENDING  [CAMERA REQUIRED]  '
                f'aligned {self.align_hold:.1f}s, altitude {dp.z:.2f}m')
            self.get_logger().info(
                '   Waiting for camera lock before descent begins …')

    def _do_descending(self, dp, pp, height_above):
        """
        Descend toward the platform.

        XY targeting:
          Camera lock available → use camera estimate (more precise close-up)
          No camera lock        → use ground-truth (always follows moving pad)

        Altitude (descent):
          Manual mode (L pressed) → always descend, no camera gate
          Auto mode               → descend only when camera lock confirmed;
                                    hold altitude while waiting for lock
        """
        # ── XY target ─────────────────────────────────────────────────────
        if self._camera_detected and self._camera_platform is not None:
            target_x = self._camera_platform.position.x
            target_y = self._camera_platform.position.y
            cam_active = True
            if not self._cam_lock_logged:
                self.get_logger().info('[CAMERA] LOCK ✓ — visual XY guidance active')
                self._cam_lock_logged = True
            self._camera_hold_warn = False
        else:
            target_x   = pp.x
            target_y   = pp.y
            cam_active  = False
            self._cam_lock_logged = False
            if not self._camera_hold_warn:
                if self._manual_descent:
                    self.get_logger().info(
                        '[CAMERA] No lock — using GPS XY, descending anyway (manual)')
                else:
                    self.get_logger().warn(
                        '[CAMERA] No lock — holding altitude, tracking GPS XY. '
                        'Press L to force descent.')
                self._camera_hold_warn = True

        # ── Descent decision ──────────────────────────────────────────────
        if self._manual_descent or cam_active:
            self.target_altitude -= self.descent_speed * self.dt
            self.target_altitude  = max(self.target_altitude, pp.z + 0.05)
        # else: hold target_altitude (auto mode waiting for camera)

        ax, ay = self._avoidance_with_events(dp)
        vx = self.pid_x.compute(target_x            - dp.x, self.dt) + ax
        vy = self.pid_y.compute(target_y            - dp.y, self.dt) + ay
        vz = self.pid_z.compute(self.target_altitude - dp.z, self.dt)

        self._set_entity(dp.x + vx * self.dt,
                         dp.y + vy * self.dt,
                         dp.z + vz * self.dt)
        self._publish_avoidance_marker(dp, ax, ay)

        if height_above < 0.35:
            self.state = self.LANDING
            self.get_logger().info('>> LANDING — final approach')

    def _do_landing(self, dp, pp, height_above):
        """Final approach — camera for XY when available, GT fallback for XY only."""
        if self._camera_detected and self._camera_platform is not None:
            target_x = self._camera_platform.position.x
            target_y = self._camera_platform.position.y
            self._camera_hold_warn = False
        else:
            # Camera lost: keep following GT so we don't lose the pad
            target_x = pp.x
            target_y = pp.y
            if not self._camera_hold_warn:
                self.get_logger().warn(
                    '[CAMERA] Lock lost in final approach — tracking GT XY')
                self._camera_hold_warn = True

        vx = self.pid_x.compute(target_x      - dp.x, self.dt)
        vy = self.pid_y.compute(target_y      - dp.y, self.dt)
        vz = self.pid_z.compute(pp.z + 0.065 - dp.z, self.dt)
        vz = max(vz, -self.final_speed)

        self._set_entity(dp.x + vx * self.dt,
                         dp.y + vy * self.dt,
                         dp.z + vz * self.dt)
        self._publish_avoidance_marker(dp, 0.0, 0.0)

        if height_above < self.land_height:
            self.state = self.LANDED
            src = 'CAMERA' if (self._camera_detected and self._camera_platform) else 'GPS'
            self.get_logger().info('=' * 46)
            self.get_logger().info(f'   LANDED SUCCESSFULLY  [{src}-GUIDED]')
            self.get_logger().info('=' * 46)

    def _do_landed(self, dp, pp):
        self._set_entity(pp.x, pp.y, pp.z + 0.065)

    # ── Avoidance ─────────────────────────────────────────────────────────

    def _avoidance_with_events(self, drone_pos) -> tuple:
        """
        Compute repulsion velocity and log enter/exit events.
        Logs [BIRD DETECTED] once when birds enter range, [BIRD CLEARED] once
        when they all leave.  Returns (avoid_x, avoid_y) in m/s.
        """
        curr_count = len(self._obstacles)

        # Event logging on transitions
        if curr_count > 0 and self._prev_obs_count == 0:
            dists = [
                math.sqrt(
                    (o.position.x - drone_pos.x) ** 2 +
                    (o.position.y - drone_pos.y) ** 2 +
                    (o.position.z - drone_pos.z) ** 2)
                for o in self._obstacles]
            nearest = min(dists)
            self.get_logger().warn(
                f'[BIRD] *** DETECTED — {curr_count} bird(s) in sensor range, '
                f'nearest at {nearest:.1f} m  → AVOIDANCE ACTIVE ***')

        elif curr_count == 0 and self._prev_obs_count > 0:
            self.get_logger().info(
                '[BIRD] All obstacles cleared — resuming normal flight')

        self._prev_obs_count = curr_count

        if not self._obstacles:
            return 0.0, 0.0

        ax, ay = 0.0, 0.0
        for obs in self._obstacles:
            ddx  = drone_pos.x - obs.position.x
            ddy  = drone_pos.y - obs.position.y
            dist = math.sqrt(ddx ** 2 + ddy ** 2)
            if dist < 0.01:
                dist = 0.01
            strength = min(self.avoid_max_vel,
                           self.avoid_gain / (dist ** 2))
            ax += strength * ddx / dist
            ay += strength * ddy / dist

        mag = math.sqrt(ax ** 2 + ay ** 2)
        if mag > self.avoid_max_vel:
            ax = ax / mag * self.avoid_max_vel
            ay = ay / mag * self.avoid_max_vel

        return ax, ay

    # ── Markers & helpers ─────────────────────────────────────────────────

    def _publish_avoidance_marker(self, dp, ax: float, ay: float):
        """Publish a red arrow in RViz showing the avoidance push direction."""
        m        = Marker()
        m.header.frame_id = 'map'
        m.header.stamp    = self.get_clock().now().to_msg()
        m.ns     = 'avoidance'
        m.id     = 0
        m.type   = Marker.ARROW

        if abs(ax) < 1e-4 and abs(ay) < 1e-4:
            m.action = Marker.DELETE
            self.avoid_marker.publish(m)
            return

        m.action = Marker.ADD
        scale    = 0.5   # arrow length scale
        m.points = [
            Point(x=dp.x, y=dp.y, z=dp.z),
            Point(x=dp.x + ax * scale,
                  y=dp.y + ay * scale,
                  z=dp.z),
        ]
        m.scale.x = 0.12   # shaft diameter
        m.scale.y = 0.22   # head diameter
        m.scale.z = 0.0
        m.color.r = 1.0
        m.color.g = 0.1
        m.color.b = 0.0
        m.color.a = 1.0
        self.avoid_marker.publish(m)

    def _move_toward(self, dp, tx, ty, tz):
        vx = self.pid_x.compute(tx - dp.x, self.dt)
        vy = self.pid_y.compute(ty - dp.y, self.dt)
        vz = self.pid_z.compute(tz - dp.z, self.dt)
        self._set_entity(dp.x + vx * self.dt,
                         dp.y + vy * self.dt,
                         dp.z + vz * self.dt)

    def _set_entity(self, x, y, z):
        state           = EntityState()
        state.name      = 'quadrotor'
        state.pose.position.x  = float(x)
        state.pose.position.y  = float(y)
        state.pose.position.z  = float(z)
        state.pose.orientation = Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)
        state.reference_frame  = 'world'
        req       = SetEntityState.Request()
        req.state = state
        self.set_client.call_async(req)


def main(args=None):
    rclpy.init(args=args)
    node = LandingController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
