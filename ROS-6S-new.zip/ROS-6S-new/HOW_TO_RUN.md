# How to Run — Autonomous Drone Landing Simulation

## Prerequisites

- Ubuntu 22.04, ROS2 Humble, Gazebo Classic (gazebo11)
- Python packages: `opencv-python`, `numpy`

```bash
sudo apt install ros-humble-gazebo-ros ros-humble-gazebo-msgs \
                 ros-humble-tf2-ros ros-humble-rviz2 \
                 ros-humble-visualization-msgs
pip install opencv-python numpy
```

---

## Build

```bash
cd ~/Desktop/CC-6S-new
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
```

---

## Mode 1 — Fully Automatic (platform moves on its own)

The platform follows a sinusoidal figure-8 path automatically. The drone
tracks, avoids birds, and lands autonomously. No keyboard input needed.

```bash
# Terminal 1 — launch everything
source /opt/ros/humble/setup.bash && source install/setup.bash
ros2 launch drone_landing simulation_launch.py
```

**What happens automatically:**
1. Gazebo + RViz open, drone spawns at (0, 0, 5 m)
2. ~3 s — drone enters TRACKING, follows the moving platform
3. Birds start flying across the drone's path → avoidance kicks in
4. Once aligned for 1.5 s → enters DESCENDING
5. Camera lock acquired → visual guidance active
6. At 0.35 m above pad → LANDING (slow final approach)
7. At 0.08 m → LANDED, drone rides the platform indefinitely

---

## Mode 2 — Manual Platform Control (WASD + L/K)

You control where the platform goes. The drone chases it. Press L to land,
K to fly back up. Use this for the interactive demo.

**Terminal 1 — launch sim without auto platform mover:**
```bash
source /opt/ros/humble/setup.bash && source install/setup.bash
ros2 launch drone_landing simulation_launch.py manual_platform:=true
```

**Terminal 2 — start WASD teleop (keep this terminal focused for key input):**
```bash
source /opt/ros/humble/setup.bash && source install/setup.bash
ros2 run drone_landing platform_teleop
```

### Controls

| Key | Action |
|-----|--------|
| `W` | Move platform forward (+X) |
| `S` | Move platform backward (−X) |
| `A` | Move platform left (+Y) |
| `D` | Move platform right (−Y) |
| `Space` | Stop platform |
| `L` | **Start descent** — drone descends and continuously chases the platform to land |
| `K` | **Abort / fly up** — drone climbs back to cruise altitude |
| `Q` | Quit teleop |

**Demo sequence suggestion:**
1. Launch Mode 2
2. Move the platform around with WASD — watch the drone follow
3. Point the platform somewhere, press `L` — drone descends and lands on it
4. Press `K` — drone flies back up
5. Move platform again, re-land with `L`

---

## Optional: launch without RViz

```bash
ros2 launch drone_landing simulation_launch.py use_rviz:=false
ros2 launch drone_landing simulation_launch.py manual_platform:=true use_rviz:=false
```

---

## Monitor in a second terminal

```bash
source /opt/ros/humble/setup.bash && source install/setup.bash

# Main status (state machine + sensor source + avoidance)
ros2 topic echo /landing/status

# Camera detection status
ros2 topic echo /camera/detection_status

# Bird/obstacle detection
ros2 topic echo /obstacle/status

# Drone position
ros2 topic echo /drone/pose

# Height above platform
ros2 topic echo /drone/height_above_platform

# All active topics
ros2 topic list

# Node graph in GUI
rqt_graph
```

---

## All Topics

| Topic | Type | Publisher | Description |
|-------|------|-----------|-------------|
| `/drone/pose` | PoseStamped | state_estimator | Drone world position |
| `/platform/pose` | PoseStamped | state_estimator | Platform world position (ground truth) |
| `/platform/pose/camera` | PoseStamped | camera_detector | Platform position estimated from camera image |
| `/relative_pose` | PoseStamped | state_estimator | Platform minus drone XYZ offset |
| `/drone/height_above_platform` | Float32 | state_estimator | Vertical distance drone→platform |
| `/drone/camera/image_raw` | Image | Gazebo plugin | Raw downward camera feed |
| `/drone/camera/debug_image` | Image | camera_detector | Annotated camera feed with detection overlay |
| `/camera/platform_detected` | Bool | camera_detector | True when yellow circle detected |
| `/camera/detection_status` | String | camera_detector | Human-readable detection status |
| `/detected_obstacles` | PoseArray | bird_detector | Bird positions within sensor range |
| `/obstacle/status` | String | bird_detector | Human-readable obstacle status |
| `/avoidance_vector` | Marker | landing_controller | RViz red arrow showing repulsion direction |
| `/landing/status` | String | landing_controller | State + guidance source + avoidance flag |
| `/landing/command` | String | platform_teleop | "DESCEND" or "ASCEND" commands |
| `/tf` | TFMessage | state_estimator | map→drone/base_link, map→platform |

---

## All Nodes

| Node | Executable | Role |
|------|------------|------|
| `state_estimator` | state_estimator | Reads Gazebo ground truth, publishes all poses and TF |
| `platform_mover` | platform_mover | Auto sinusoidal platform motion (disabled in manual mode) |
| `platform_teleop` | platform_teleop | WASD manual platform + L/K landing commands |
| `camera_detector` | camera_detector | OpenCV HSV detection of yellow pad circle, publishes camera pose estimate |
| `bird_mover` | bird_mover | Moves 3 orange bird obstacles in circular paths at drone altitude |
| `bird_detector` | bird_detector | Publishes birds within 3 m of drone (simulates proximity sensor) |
| `landing_controller` | landing_controller | PID state machine, obstacle avoidance, camera/GPS switching |

---

## Troubleshooting

**Gazebo won't start / service not found:**
```bash
killall -9 gzserver gzclient
pkill -9 -f drone_landing
# Then relaunch
```

**Drone not moving after launch:**
- Wait ~8 seconds for all nodes to start (5 s delay + WAITING state)
- Check: `ros2 topic echo /landing/status`

**Camera not detecting platform:**
- Check: `ros2 topic echo /camera/detection_status`
- View the annotated camera feed in RViz under "Downward Camera"
- If showing NOT DETECTED, the yellow blob may not be in frame yet (drone still high)

**Build errors after changes:**
```bash
rm -rf build/ install/ log/
colcon build
source install/setup.bash
```
